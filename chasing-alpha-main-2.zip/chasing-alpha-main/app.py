import json
import os
import traceback
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from socketserver import ThreadingMixIn

from orchestrator.graph import build_graph

ROOT_DIR = Path(__file__).resolve().parent
CONFIG_PATH = Path(os.environ.get("CONFIG_FILE", ROOT_DIR / "config.json"))
PORT = int(os.environ.get("PORT", "8080"))


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"Config file not found: {CONFIG_PATH}")
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


CONFIG = load_config()


def run_pipeline(state: dict) -> dict:
    graph = build_graph()
    return graph.invoke(state)


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


class RequestHandler(BaseHTTPRequestHandler):
    def _send_json(self, data: dict, status: int = HTTPStatus.OK) -> None:
        payload = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8") if length else ""
        return json.loads(body) if body else {}

    def _get_value(self, payload: dict, *keys: str):
        for key in keys:
            if payload.get(key) not in (None, ""):
                return payload.get(key)

        nested = payload.get("data")
        if isinstance(nested, dict):
            for key in keys:
                if nested.get(key) not in (None, ""):
                    return nested.get(key)

        return None

    def do_GET(self):
        if self.path in {"/", "/health"}:
            provider = os.environ.get("LLM_PROVIDER", CONFIG.get("llm_provider", "gemini"))
            self._send_json({
                "status": "ok",
                "message": "Kapitalwerk NXT Cloud Run service is available.",
                "project_id": CONFIG.get("project_id"),
                "gcs_bucket": CONFIG.get("gcs_bucket"),
                "llm_provider": provider,
            })
            return

        if self.path == "/run":
            self._send_json({
                "status": "ok",
                "message": "Use POST /run with a JSON body to trigger the pipeline.",
            })
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Not Found")

    def do_POST(self):
        if self.path != "/run":
            self.send_error(HTTPStatus.NOT_FOUND, "Not Found")
            return

        try:
            payload = self._read_json()
            customer_id = self._get_value(payload, "customer_id", "customerId")
            source_type = self._get_value(payload, "source_type", "sourceType", "source_type_name")
            csv_path = self._get_value(payload, "csv_path", "csvPath", "file_path")
            run_date = self._get_value(payload, "run_date", "runDate")

            if not customer_id or not source_type or not csv_path:
                raise ValueError("customer_id, source_type, and csv_path are required")

            state = {
                "customer_id": customer_id,
                "source_type": source_type,
                "csv_path": csv_path,
            }
            if run_date:
                state["run_date"] = run_date

            result = run_pipeline(state)
            self._send_json({"success": True, "result": result})
        except ValueError as exc:
            self._send_json({"success": False, "error": str(exc)}, status=HTTPStatus.BAD_REQUEST)
        except Exception as exc:
            # Cloud Run only captures stdout/stderr, not response bodies -- print
            # the full traceback so 500s are diagnosable from Cloud Logging.
            traceback.print_exc()
            self._send_json({"success": False, "error": str(exc)}, status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def log_message(self, format: str, *args) -> None:
        # Cloud Run captures stdout/stderr logs.
        print(f"{self.address_string()} - {format % args}")


if __name__ == "__main__":
    print(f"Starting Kapitalwerk NXT service on port {PORT}")
    server = ThreadingHTTPServer(("0.0.0.0", PORT), RequestHandler)
    server.serve_forever()
