# Deploying the weekly reminder emails (GCP)

This describes deploying `run_weekly.sh` (Monday "upcoming payment" /
Friday "missed payment" emails, real SendGrid delivery) as a **Cloud Run
Job** triggered by **Cloud Scheduler**. It builds on the existing
`Dockerfile` at the repo root — no separate image is needed.

## 1. Get a SendGrid API key + verified sender

1. Create a SendGrid account (or use an existing one), then
   **Settings → API Keys → Create API Key** with *Mail Send* permission.
   The key starts with `SG.` — copy it once, it isn't shown again.
2. Verify a sender: **Settings → Sender Authentication**. Fastest path is
   *Single Sender Verification* for one address (e.g.
   `reports@kapitalwerknxt.bank`, or whatever domain you actually control —
   SendGrid will reject sends from an address it hasn't verified).
   Domain authentication (SPF/DKIM/DMARC via Sender Authentication → Domain
   Authentication) is the production-grade version of this and improves
   deliverability, but takes DNS propagation time — fine to add after the
   first working demo.
3. Keep `SENDGRID_SANDBOX_MODE=true` until you've confirmed the request
   shape is right (see `test_email_client.py` for what that looks like, or
   run a manual sandbox send — step 5 below) — sandbox mode gets you a real
   `200`/`202` from SendGrid's API without delivering anything, so you can
   verify auth + payload before flipping it off.

## 2. Store the key in Secret Manager (don't put it in a plain env var)

```bash
gcloud secrets create sendgrid-api-key --replication-policy=automatic
echo -n "SG.your-real-key-here" | gcloud secrets versions add sendgrid-api-key --data-file=-
```

## 3. Build and push the image

```bash
# from the repo root
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/kapitalwerknxt-pipeline
```

## 4. Create the Cloud Run Job

```bash
gcloud run jobs create kapitalwerknxt-weekly-reminders \
  --image gcr.io/YOUR_PROJECT_ID/kapitalwerknxt-pipeline \
  --region YOUR_REGION \
  --set-secrets SENDGRID_API_KEY=sendgrid-api-key:latest \
  --set-env-vars SENDGRID_FROM_EMAIL=reports@kapitalwerknxt.bank,SENDGRID_SANDBOX_MODE=true,LLM_PROVIDER=mock \
  --command "/app/reporting_agent/run_weekly.sh" \
  --args "monday"
```

`--args` is what makes this one job double as both triggers — Cloud
Scheduler overrides it per-schedule (step 5), so the image and job
definition stay identical for both.

`LLM_PROVIDER=mock` above is a placeholder — the Friday run also executes
Risk/AML, which call an LLM through `governance/llm_client.py`. Set
`LLM_PROVIDER=gemini` and `GEMINI_API_KEY` (another Secret Manager binding)
once that's ready for production; `mock` is only fine for a demo.

## 5. Wire up the two Cloud Scheduler triggers

```bash
# Monday, 7am — upcoming-payment notices
gcloud scheduler jobs create http kapitalwerknxt-monday-upcoming \
  --schedule "0 7 * * MON" \
  --uri "https://REGION-run.googleapis.com/apis/run.googleapis.com/v1/namespaces/YOUR_PROJECT_ID/jobs/kapitalwerknxt-weekly-reminders:run" \
  --http-method POST \
  --oauth-service-account-email YOUR_INVOKER_SA@YOUR_PROJECT_ID.iam.gserviceaccount.com \
  --message-body '{"overrides":{"containerOverrides":[{"args":["monday"]}]}}'

# Friday, 5pm — missed-payment reminders (full pipeline)
gcloud scheduler jobs create http kapitalwerknxt-friday-missed \
  --schedule "0 17 * * FRI" \
  --uri "https://REGION-run.googleapis.com/apis/run.googleapis.com/v1/namespaces/YOUR_PROJECT_ID/jobs/kapitalwerknxt-weekly-reminders:run" \
  --http-method POST \
  --oauth-service-account-email YOUR_INVOKER_SA@YOUR_PROJECT_ID.iam.gserviceaccount.com \
  --message-body '{"overrides":{"containerOverrides":[{"args":["friday"]}]}}'
```

The invoker service account needs `roles/run.invoker` on the job. Times
above are illustrative — pick whatever "start of week" / "end of week"
means for your ops team, in the job's configured timezone
(`--time-zone` flag on `gcloud scheduler jobs create`, defaults to UTC).

## 6. Verify one real end-to-end run manually before trusting the schedule

```bash
gcloud run jobs execute kapitalwerknxt-weekly-reminders \
  --region YOUR_REGION \
  --args monday \
  --update-env-vars REMINDER_RECIPIENT_OVERRIDE=your-test-inbox@example.com
```

`REMINDER_RECIPIENT_OVERRIDE` routes the run's email to one address instead
of the customer's on-file address — handy for a smoke test. Each run sends
**at most one email per persona** (to the one business customer — Claire /
Mark / Arya), aggregating that customer's whole book of counterparties; the
bank never emails the underlying hospitals/members. See the docstring at the
top of `weekly_reminders.py` and `contact_store.py` for the persona-level
contact model, and why a send is *skipped* rather than guessed at when no
recipient is known. Check Cloud Logging for that execution to confirm
`[weekly_reminders] monday for <persona>: 1 sent, 0 skipped`.

## 7. Turn off sandbox mode once you trust it

```bash
gcloud run jobs update kapitalwerknxt-weekly-reminders \
  --region YOUR_REGION \
  --update-env-vars SENDGRID_SANDBOX_MODE=false
```

## What's still a gap after this

- **Demo customer contact email.** The contact directory (see
  `contact_store.py`) now holds one record per business customer (Claire /
  Mark / Arya), but every record's `email` is the single safe demo inbox.
  Before a real production run, swap those three addresses for the customers'
  real ones; the send path already reads the directory, so no code change is
  needed once the emails are real.
- **`bucket_output` is local-disk only.** `storage.py`'s `LocalBucket`
  doesn't survive a Cloud Run Job's ephemeral filesystem between separate
  executions in the way a real deployment needs (Monday's ingestion output
  needs to still be there when Friday's job runs, unless Friday's job
  re-ingests itself, which it does today via the full pipeline — but this
  means Monday and Friday runs are currently independent, not reading each
  other's output). Swap in `GCSBucket` (already stubbed in `storage.py`)
  before relying on this past a demo.
- **Compliance footer / unsubscribe link** isn't in the email templates
  yet — required before sending real production email at any volume
  (CAN-SPAM / GDPR).
