# Kapitalwerk NXT

## What this project does

Kapitalwerk NXT is a multi-agent transaction monitoring pipeline for SME banking use cases.
It ingests customer transaction files, computes anomaly and risk signals, optionally runs AML narratives through an LLM with governance controls, generates reporting artifacts, and exposes everything through an API and bundled UI.

## Core components

- Ingestion agent: normalizes source CSV data and writes snapshot artifacts
- Inflow agent: computes flags such as missing payments, deviations, and high-value transactions
- Risk agent: derives risk tier and signals, plus PII fail-closed gating
- AML agent: creates case narratives for escalated flags
- Marketing agent: builds postal-code heatmap annotations
- Reporting agent: reminder outputs, top-risk report, exports used by API/UI
- Governance: LLM budget, caching, audit trail, provider abstraction
- Orchestrator: LangGraph workflow wiring all nodes
- API service: read and action endpoints plus standalone UI at /

## End-to-end flow

Execution order in orchestrator graph:

1. ingestion_node
2. inflow_node
3. risk_node
4. Conditional branch:
5. aml_node if escalation criteria met, else skip to reporting
6. reporting_node
7. marketing_node
8. reminder_node

Flow source: orchestrator/graph.py.

## Storage model

Per-run artifacts are stored under:

- customer_id/run_date/normalized_transactions.json
- customer_id/run_date/inflow_flags.json
- customer_id/run_date/top_risk_report.json
- customer_id/run_date/marketing_heatmap.json
- plus related reporting and audit outputs

Bucket backend is environment-driven:

- local: LocalBucket
- gcs: MirrorBucket (reads from GCS first, writes to both local and GCS)

## LLM and governance model

- LLM provider is selected by LLM_PROVIDER
- Supported: mock, vertex, gemini, ollama
- Governance store is selected by GOVERNANCE_STORE
- Supported: memory (default), firestore

Only selected nodes call LLMs directly, and all LLM calls pass through GovernanceMiddleware.

## Local setup

Prerequisites:

- Python 3.10+
- pip

Install dependencies:

pip install -r requirements.txt

Optional: create a .env file in repo root for local overrides.

## Run the full pipeline locally

Run from orchestrator folder:

cd orchestrator
python3 run_orchestrator.py

Useful environment flags:

- RUN_ALL_PERSONAS=1 to process all personas
- FORCE_RUN=1 to force rerun even if snapshot exists
- RUN_DATE=YYYY-MM-DD to backfill or re-run a date
- BUCKET_BACKEND=local or gcs

## Run the Cloud Run agent endpoint locally

The root app.py exposes:

- GET /health
- POST /run

Start service:

python3 app.py

Example run request:

curl -X POST "http://localhost:8080/run" -H "Content-Type: application/json" -d '{"customer_id":"glucometer-vendor","source_type":"hospital_vendor","csv_path":"../ingestion_data/hospital_vendor_2yr_history.csv"}'

## API service

api/main.py exposes read and action endpoints and serves the UI from /.

Important endpoints:

- POST /api/run (forwards to agent service via AGENT_URL)
- GET /api/personas
- GET /api/{persona}/dashboard
- GET /api/{persona}/cases
- GET /api/{persona}/marketing-heatmap
- POST /api/{persona}/cases/{case_id}/acknowledge
- POST /api/{persona}/cases/{case_id}/escalate
- GET /api/governance/audit-summary

## Cloud deployment

cloudbuild.yaml builds and deploys two Cloud Run services:

1. kapitalwerk-agent
2. kapitalwerk-api

Highlights:

- Agent is deployed first
- API gets AGENT_URL from deployed agent service
- BUCKET_BACKEND=gcs and GCS bucket name are injected via env vars
- Optional Firestore governance backend can be enabled with GOVERNANCE_STORE=firestore

Run deploy:

gcloud builds submit --config cloudbuild.yaml .

## Test commands

Run all module tests:

for d in ingestion_agent inflow_agent risk_agent aml_agent governance reporting_agent marketing_agent; do (cd "$d" && python3 -m pytest -q); done

## Key env vars

- BUCKET_BACKEND: local or gcs
- GCS_BUCKET_NAME: target GCS bucket when BUCKET_BACKEND=gcs
- LLM_PROVIDER: mock, vertex, gemini, ollama
- GEMINI_MODEL: model name for gemini or vertex
- AGENT_URL: API-to-agent forwarding endpoint
- GOVERNANCE_STORE: memory or firestore
- FIRESTORE_PROJECT: optional explicit project for firestore backend
- FIRESTORE_DATABASE: firestore database id, default is (default)
- REMINDER_NOTIFIER: console or resend
- RESEND_API_KEY: required when REMINDER_NOTIFIER=resend

## File map

- app.py: Cloud Run style run endpoint
- orchestrator/run_orchestrator.py: local and batch orchestrator runner
- orchestrator/graph.py: node wiring and conditional path
- orchestrator/nodes.py: node implementations
- api/main.py: API and UI service
- cloudbuild.yaml: build and deploy pipeline
