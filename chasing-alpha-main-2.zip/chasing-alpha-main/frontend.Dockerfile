FROM python:3.12-slim

WORKDIR /app

# Serve the standalone UI file using Python's simple HTTP server
COPY standalone-ui.html /app/

ENV PORT=8080
EXPOSE 8080

CMD ["python", "-m", "http.server", "8080"]
