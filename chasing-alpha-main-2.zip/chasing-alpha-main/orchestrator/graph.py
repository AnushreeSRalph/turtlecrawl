r"""The orchestrator itself: wires the five agents into one LangGraph graph.

ingestion -> inflow -> risk --------\
"""


from langgraph.graph import StateGraph, END

from pathlib import Path
import sys

ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from state import PipelineState
from nodes import (
    ingestion_node, inflow_node, risk_node, aml_node,
    reporting_node, marketing_node, reminder_node, should_run_aml,
)


def build_graph():
    graph = StateGraph(PipelineState)

    graph.add_node("ingestion_node", ingestion_node)
    graph.add_node("inflow_node", inflow_node)
    graph.add_node("risk_node", risk_node)
    graph.add_node("aml_node", aml_node)
    graph.add_node("reporting_node", reporting_node)
    graph.add_node("marketing_node", marketing_node)
    graph.add_node("reminder_node", reminder_node)

    graph.set_entry_point("ingestion_node")
    graph.add_edge("ingestion_node", "inflow_node")
    graph.add_edge("inflow_node", "risk_node")

    # conditional edge: only spend LLM tokens if Inflow found something
    # worth escalating
    graph.add_conditional_edges(
        "risk_node",
        should_run_aml,
        {"aml_node": "aml_node", "reporting_node": "reporting_node"},
    )

    graph.add_edge("aml_node", "reporting_node")
    graph.add_edge("reporting_node", "marketing_node")
    graph.add_edge("marketing_node", "reminder_node")
    graph.add_edge("reminder_node", END)

    return graph.compile()
